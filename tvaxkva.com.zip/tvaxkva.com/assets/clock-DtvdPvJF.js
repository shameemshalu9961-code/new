import{a as c}from"./index-n3ykPomq.js";const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]],a=c("clock",o);export{a as C};
